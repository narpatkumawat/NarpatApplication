import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
    {
        path: '',
        loadChildren: './pages/login/login.module#LoginModule'
    },
    {
        path: 'forgotpassword',
        loadChildren: './pages/forgot-password/forgotpassword-module#ForgotpasswordModule'
    },
    {
        path: 'dashboard',
        loadChildren: './pages/dashboard/dashboard.module#DashboardModule'
    },
    {
        path: 'changepassword',
        loadChildren: './pages/adminprofile/adminprofile.module#AdminProfileModule'
    },

    {
        path: 'memberlist',
        loadChildren: './pages/Member/member-list/member-list-module#MemberListModule'
    },
    {
        path: 'memberadd',
        loadChildren: './pages/Member/add-member/add-member-module#AddMemberModule'
    },
    {
        path: 'memberedit',
        loadChildren: './pages/Member/edit-member/edit-member-module#EditMemberModule'
    },
    {
        path: 'itemlist',
        loadChildren: './pages/Item/item-list/itemlist-module#ItemlistModule'
    },
    {
        path: 'itemadd',
        loadChildren: './pages/Item/add-item/add-item-module#AddItemModule'
    },
    {
        path: 'itemedit/:id',
        loadChildren: './pages/Item/edit-item/edit-item-module#EditItemModule'
    },
    {
        path: 'addcity',
        loadChildren: './pages/LocationMaster/add-city/add-city-module#AddCityModule'
    },
    {
        path: 'editcity/:id',
        loadChildren: './pages/LocationMaster/edit-city/edit-city-module#EditCityModule'
    },
    {
        path: 'citylist',
        loadChildren: './pages/LocationMaster/city-master/city-module#CityModule'
    },
    {
        path: 'blocklist',
        loadChildren: './pages/LocationMaster/block-master/block-module#BlockModule'
    },
    {
        path: 'addblock',
        loadChildren: './pages/LocationMaster/add-block/add-block-module#AddBlockModule'
    },
    {
        path: 'editblock/:id',
        loadChildren: './pages/LocationMaster/edit-block/edit-block-module#EditBlockModule'
    },
    {
        path: 'proprietorlist',
        loadChildren: './pages/Proprietor/proprietor-list/propietor-list-module#PropietorListModule'
    },
    {
        path: 'addproprietor',
        loadChildren: './pages/Proprietor/add-properitoe/add-properitor-module#AddProperitorModule'
    },
    {
        path: 'editproprietor/:id',
        loadChildren: './pages/Proprietor/edit-proprietor/edit-properitor-module#EditProperitorModule'
    },
    {
        path: 'adduser',
        loadChildren: './pages/UserMaster/adduser/adduser-module#AdduserModule'
    },
    {
        path: 'userlist',
        loadChildren: './pages/UserMaster/user-list/user-list-module#UserListModule'
    },
    {
        path: 'edituser/:id',
        loadChildren: './pages/UserMaster/edit-user/edit-user-module#EditUserModule'
    },
    {
        path: 'bankbalance',
        loadChildren: './pages/Payment/bank-balence/bank-balence-module#BankBalenceModule'
    },
    {
        path: 'balancedetails',
        loadChildren: './pages/Payment/bank-details/bank-details-module#BankDetailsModule'
    },
    {
        path: 'payforcompany',
        loadChildren: './pages/IncentivePay/pay-company/pay-company-module#PayCompanyModule'
    },
    {
        path: 'payformember',
        loadChildren: './pages/IncentivePay/pay-member/pay-member-module#PayMemberModule'
    },
    {
        path: 'limitincrease',
        loadChildren: './pages/IncentivePay/limit-increase/limitincease-module#LimitinceaseModule'
    },
    {
        path: 'ledgermember',
        loadChildren: './pages/LedgerMember/memberledger/ledger-module#LedgerModule'
    },
    {
        path: 'memberincentive',
        loadChildren: './pages/LedgerMember/member-incentive/incentive-module#IncentiveModule'
    },
    {
        path: 'companyledger',
        loadChildren: './pages/LedgerMember/company-ledger/ledger-member-module#LedgerMemberModule'
    },
    {
        path: 'tdsledger',
        loadChildren: './pages/LedgerMember/tdsledger/tdsmodule#TDSModule'
    },
    {
        path: '404',
        loadChildren: './pages/error/error.module#ErrorModule'
    },
    {
        path: 'salesreports',
        loadChildren: './pages/sales-report/sales-report-module#SalesReportModule'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
