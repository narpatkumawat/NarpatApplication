export class Admin {
    public id: number
    public email: string
    public name: string
    public username: string
    public mobile: string;
    public password: string;
    public roleType: string;
    public confirmPassword: string;
    public isActive: boolean;
    public status: number;
    public oldpassword: string;
    public newpassword: string;
}