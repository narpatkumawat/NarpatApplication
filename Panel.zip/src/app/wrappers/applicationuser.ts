export class ApplicationUser{
    public id:number
    public name:string
    public email:string
    public mobile:string
    public address:string
}