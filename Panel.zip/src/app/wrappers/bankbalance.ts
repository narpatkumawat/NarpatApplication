export class Bankbalance {
    public  id :number;
    public mId :number;
    public  TransactionId :string;
    public  CreaditAmt : number;
    public  DebitAmt : number;
    public  ClosingBalance : number;
    public  AcountNo :string;
    public  CreatedDate: Date;
    public  FromDate : Date;
    public  ToDate : Date;
    public TransactionDate : Date;
}
