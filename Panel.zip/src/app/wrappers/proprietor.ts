export class Proprietor {
    public id: number
    public srNo:string;
    public propriterName: string
    public framName: string
    public stateName: string
    public cityName: string
    public blockName: string
    public address: string
    public mobile: string
    public email: string
    public password: string
    public stateId:number;
    public cityId:number;
    public blockId:number;
    public status:number;
    public IsActive:boolean;
}
