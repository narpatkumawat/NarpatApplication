export class MemberIncLedger {
    public id: number;
    public membercode: string;
    public Totalincentive: number;
    public PaidAmount: number;
    public Balance: number;
    public TransactionDate: Date;
    public IncentiveAmount: number;
    public FromDate: Date;
    public ToDate: Date;
    public CreatedDate: Date;
    public isActive: boolean;
    public status: string
}
