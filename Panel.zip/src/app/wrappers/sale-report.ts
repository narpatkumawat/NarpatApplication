export class SaleReport {
    public id: number;
    public srno: string;
    public SalesAmount: number;
    public commAmt: number;
    public state: string;
    public city: string;
    public block: string;
    public salesDate: Date;
    public propriterName: string;
    public fromdate: Date;
    public todate: Date;
    public PropriterId: number;
    public stateid: number;
    public cityid: number;
    public blockid: number;
}

