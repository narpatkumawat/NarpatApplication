export class Payforcompany {
    public id: number;
    public TransactionId: string;
    public CreaditAmt: number;
    public DebitAmt: number;
    public ClosingBalance: number;
    public AcountNo: string;
    public TransactionDate: Date;
    public CreatedDate: Date;
}
