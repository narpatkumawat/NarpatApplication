export class City {
    public id:number;
    public stateid:number;
    public name:string;
    public isActive:boolean

}
