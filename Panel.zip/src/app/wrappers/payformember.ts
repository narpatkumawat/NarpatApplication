export class Payformember {
    public id :number;
    public MemberName :string;
    public transactionId :string;
    public amount :number;
    public Totalincentive :number;
    public  PaidAmount :number;
    public  IncentiveAmount :number;
    public  Balance :number;
    public  membercode :string;
    public  accountNo :string;
    public  RegistrationDate :Date;
    public  ValidFrom :Date;
    public  ValidTo :Date;
    public  FromDate :Date;
    public  ToDate :Date;
    public  status:string;
}
