export class Item {
    public id: number;
    public propriterId: number
    public itemName: string;
    public Quantity: string
    public mrp: number
    public image: string;
    public isActive: boolean;
    public offer: boolean;
}
