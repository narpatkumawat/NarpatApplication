export class TdsLedger {
    public id: number;
    public Netincentive: number;
    public Totalincentive: number;
    public TotalTDS: number;
    public name: string;
    public panCard: string;
    public FromDate: Date;
    public ToDate: Date;
    public CreatedDate: Date;
    public isActive: boolean;
    public status: string;
    public mobile: string
}
