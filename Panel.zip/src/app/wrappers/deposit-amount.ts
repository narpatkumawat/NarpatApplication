export class DepositAmount {
    public  id :number;
    public mId :number;
    public  TransactionId :string;
    public  CreaditAmt : number;
    public  DebitAmt : number;
    public  ClosingBalance : number;
    public  AcountNo :string;
    public  registrationDate: Date;
    public  FromDate : Date;
    public  ToDate : Date;
    public name:string;
    public memberId:string;
    public denaminalionamt:number;
    public adharno: string;
}
