export class Block {
    public id:number;
    public stateId:number
    public cityId:number;
    public isActive:boolean;
}
