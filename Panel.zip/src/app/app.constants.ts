import { Injectable } from '@angular/core';

@Injectable()
export class Configuration {
    // public API_ENDPOINT = "http://localhost:53970/api/v1/";
    public API_ENDPOINT = "http://api.amarashwamedh.in/api/v1/";
    //public API_ENDPOINT = "http://devapi.amarashwamedh.in/api/v1/";
}
