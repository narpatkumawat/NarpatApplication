import { Injectable} from '@angular/core';
import {Http, Response} from "@angular/http";
import { Observable } from 'rxjs';
import "rxjs/Rx";
// import { map, filter, scan } from 'rxjs/operators';

@Injectable()
export class DataService{

    constructor(private http: Http){
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }

    public getData<T>(url:string){
        return this.http.get(url).map((response: Response) => {
            return response.json();
        })
        .catch(this.handleError);
    }

    public postData<T>(url:string,toAdd: any) {
               return this.http.post(url, toAdd).map((response: Response) => {
            return response.json();
        })
        .catch(this.handleError);
    }

    public deleteData<T>(url:string){
        return this.http.delete(url).map((response: Response) => {
            return response.json();
        })
        .catch(this.handleError);
    }
}