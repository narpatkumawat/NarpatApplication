import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from './data.service';

@Injectable()
export class AdminService {

    constructor(private _configuration: Configuration,
        private _dataService: DataService) {
    }

    public adminLogin(body) {
        return this._dataService.postData(
            this._configuration.API_ENDPOINT + 'invoice/userslogin', body
        );
    }
    public getAllUsers() {
        return this._dataService.getData(
            this._configuration.API_ENDPOINT + 'invoice/getallusers'
        );
    }

    public saveUser(body) {
        return this._dataService.postData(
            this._configuration.API_ENDPOINT + 'invoice/signup', body
        );
    }

    public updateUser(body) {
        return this._dataService.postData(
            this._configuration.API_ENDPOINT + 'invoice/updateuser', body
        );
    }

    public getByuserId(body) {
        return this._dataService.getData(
            this._configuration.API_ENDPOINT + 'invoice/getusersby/' + body
        );
    }
    public UpdateProfile(body) {
        return this._dataService.postData(
            this._configuration.API_ENDPOINT + 'admin/updateprofile', body
        );
    }

    public ChangePassword(body) {
        return this._dataService.postData(
            this._configuration.API_ENDPOINT + 'invoice/userchangepassword', body
        );
    }
    public getDashboard() {
        return this._dataService.getData(
            this._configuration.API_ENDPOINT + 'invoice/getdashboard'
        );
    }

    public forgotPassword(body) {
        return this._dataService.postData(
            this._configuration.API_ENDPOINT + 'invoice/forgotpassword', body
        )
    }


}