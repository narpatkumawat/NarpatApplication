import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from '../services/data.service';

@Injectable()
export class LedgerService {
  constructor(private _configuration: Configuration, private _dataService: DataService) {
  }
  public depositBalance(body) {
     
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/depositbalance', body
    );
  }

  public PayToCompanyAmount(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/payforcompany', body
    );
  }

  public memberVerify(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/memberverify', body
    );
  }
  public ShowBalancesheet(body) {
        return this._dataService.postData(
          this._configuration.API_ENDPOINT + 'invoice/getbalancesheet', body
        );
      }
      public VerifyMemberData(body) {
        return this._dataService.postData(
          this._configuration.API_ENDPOINT + 'invoice/verifymemberdata', body
        );
      }
      public PayMemberIncentive(body) {
         
        return this._dataService.postData(
          this._configuration.API_ENDPOINT + 'invoice/payformember', body
        );
      }
      public getDenomationAmount() {
        return this._dataService.getData(
          this._configuration.API_ENDPOINT + 'invoice/alldeamount'
        );
      }
      public LimitIncrease(body) {
         
        return this._dataService.postData(
          this._configuration.API_ENDPOINT + 'invoice/limitincrease', body
        );
      }
      public CompanyLegger(body) {
        return this._dataService.postData(
          this._configuration.API_ENDPOINT + 'invoice/companylegger', body
        );
      }
}
