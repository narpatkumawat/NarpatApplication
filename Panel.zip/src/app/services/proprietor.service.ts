import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from './data.service';


@Injectable()

export class ProprietorService {

  constructor(private _configuration: Configuration,
    private _dataService: DataService) {
  }

  public addProprietor(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/addprop', body
    );
  }

  public editProprietor(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/updateproprietor', body
    );
  }
  public proprietorSearch(body) {
        return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/propritersearch', body
    );
  }

  public getproprietorById(body) {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/getpropriterby/' + body
    );
  }
}
