import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from './data.service';

@Injectable()

export class MemberService {

  constructor(private _configuration: Configuration,
    private _dataService: DataService) {
  }

  public memberSearch(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/membersearch', body
    );
  }
  updateMember(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/updatemember', body
    );
  }

  getMemberbyId(body) {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/getuserdetails/' + body
    );
  }
  updateStatus(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/statusupdate', body
    );
  }
  public memberLegger(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/memberleggar', body
    );
  }

  public memberIncLedger(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/memberincledger', body
    );
  }

  public tdsLedger(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/tdsledger', body
    );
  }
}
