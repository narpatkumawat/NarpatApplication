import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from './data.service';

@Injectable()
export class MasterService {

  constructor(private _configuration: Configuration,
    private _dataService: DataService) {
  }

  public getAllState() {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/allstate'
    );
  }

  public getAllCity(body) {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/allcity/' + body
    );
  }

  public addCity(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/addcity', body
    );
  }

  public getAllBlock(body) {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/allblock/' + body
    );
  }

  public getAllBlockList() {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/getblockdata'
    );
  }


  public AllCity() {

    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/Getcitydata'
    );
  }

  public getcityById(body) {

    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/getcitybyid/' + body
    );
  }

  public editCity(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/updatecity', body
    );
  }

  public addBlock(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/addblock', body
    );
  }

  public getblockBy(body) {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/getblockby/' + body
    );
  }

  public editBlock(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/updateblock', body
    );
  }

  public getProprietorByBlock(body) {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/propriterbyblock/' + body
    );
  }

  public searchsaleReport(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/salereport', body
    );
  }
}
