import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from './data.service';

@Injectable()
export class ApplicationUserService {

    constructor(private _configuration: Configuration,
        private _dataService: DataService) {

    }

    public getAllUsers() {
        return this._dataService.getData(
            this._configuration.API_ENDPOINT + 'admin/user/getall'
        );
    }
}