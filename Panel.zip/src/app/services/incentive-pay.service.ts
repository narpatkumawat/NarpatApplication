import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from '../services/data.service';

@Injectable()
export class IncentivePayService {
  constructor(private _configuration: Configuration,
    private _dataService: DataService) { }

  addPayCompany(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + '', body
    );
  }
  
  
}
