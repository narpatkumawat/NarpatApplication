import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from '../services/data.service';

@Injectable()
export class PaymentService {
  constructor(private _configuration: Configuration,
    private _dataService: DataService) {
  }

  public saveCompanyPay(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/savecompanypay', body
    );
  }
}
