import { Injectable } from '@angular/core';
import { Configuration } from '../app.constants';
import { DataService } from './data.service';

@Injectable()
export class ItemService {
  constructor(private _configuration: Configuration,
    private _dataService: DataService) {
  }

  public addItem(body) {
    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/additem', body
    );
  }
  public getallpropriter() {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/getallpropriter'
    );
  }

  public searchItems(body) {

    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/searchitem', body
    );
  }

  public editItems(body) {

    return this._dataService.postData(
      this._configuration.API_ENDPOINT + 'invoice/updateitem', body
    );
  }

  public getItemsbyId(body) {
    return this._dataService.getData(
      this._configuration.API_ENDPOINT + 'invoice/getitemby/' + body
    );
  }
}
