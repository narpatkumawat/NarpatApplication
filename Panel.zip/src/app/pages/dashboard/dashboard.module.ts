import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { MenuModule } from '../../components/menu/menu.module';
import { AdminService } from '../../services/admin.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ChartsModule } from 'ng2-charts';

@NgModule({
    imports: [
        CommonModule,
        DashboardRoutingModule,
        MenuModule,
        NgxSpinnerModule,
        ChartsModule
    ],
    declarations: [
        DashboardComponent
    ],
    exports: [

    ],
    providers: [AdminService]
})
export class DashboardModule {
}