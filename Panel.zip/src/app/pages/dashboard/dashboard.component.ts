import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { AdminService } from '../../services/admin.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
    selector: 'dashboard-page',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class DashboardComponent {
    adminName: any;
    countPropriter: any;
    countItems: any;
    countMember: any;
    countofferItems: any;

    constructor(public router: Router, private chRef: ChangeDetectorRef, private toastr: ToastrManager, private _adminService: AdminService, private spinner: NgxSpinnerService) {
        var user = JSON.parse(window.localStorage.getItem('user')) as any;
        if (user == undefined || user == null) {
            this.router.navigate(['']);
        }
    }

    public barChartOptions: any = {
        scaleShowVerticalLines: false,
        responsive: true,
        barThickness: 10
    };

    public barChartLabels: string[] = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    public barChartType = 'bar';
    public barChartLegend = true;

    // tslint:disable-next-line:max-line-length
    public barChartData: any[] = [{ data: [65, 59, 80, 81, 56, 55, 67, 59, 80, 81, 56, 55], label: 'Proprietor' }];
    public memberChartColors: Array<any> = [{ backgroundColor: '#dc3545' }];
    public barChartDataClients: any[] = [{ data: [65, 59, 80, 81, 56, 55, 67, 59, 80, 81, 56, 55], label: 'Member' }];

    public barChartDataProjects: any[] = [{ data: [65, 59, 80, 81, 56, 55, 67, 59, 80, 81, 56, 55], label: 'Items' }];
    public itemsChartColors: Array<any> = [{ backgroundColor: '#e6a1f2 ' }];
    public barChartDataEvents: any[] = [{ data: [65, 59, 80, 81, 56, 55, 67, 59, 80, 81, 56, 55], label: 'Offereble Items' }];

    public offereblesChartColors: Array<any> = [{ backgroundColor: '#28a745' }];
    public usersChartColors: Array<any> = [{ backgroundColor: '#007bff' }];

    ngOnInit() {
        this.Allcounter();
    }
    public chartClicked(e: any): void {
        // console.log(e);
    }
    public chartHovered(e: any): void {
        // console.log(e);
    }

    Allcounter() {
        this.spinner.show();
        this._adminService.getDashboard().subscribe(
            resultArray => {
                if (resultArray.status == 200) {
                    this.countPropriter = resultArray.propriter;
                    this.countItems = resultArray.items;
                    this.countMember = resultArray.members;
                    this.countofferItems = resultArray.offerebleItems;
                    this.chRef.detectChanges();
                }
                else {
                    this.toastr.warningToastr(resultArray.message, 'Record not found', {
                        position: "bottom-center",
                        toastTimeout: 2000,
                        animate: "slideFromBottom"
                    });
                }
                this.spinner.hide();
            },
            error => {
                this.toastr.warningToastr(error, 'Record not found', {
                    position: "bottom-center",
                    toastTimeout: 2000,
                    animate: "slideFromBottom"
                });
                return;
            });
    }

    isNullOrEmpty(data) {
        return (data == undefined || data == null || data == "") ? "0" : data;
    }
}