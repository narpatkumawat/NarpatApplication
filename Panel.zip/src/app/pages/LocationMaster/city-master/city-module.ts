import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CityRoutingModule } from '../../LocationMaster/city-master/city-routing-module';
import { CityMasterComponent } from '../../LocationMaster/city-master/city-master.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { MasterService } from '../../../services/master.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        CommonModule,
        CityRoutingModule,
        MenuModule,
        NgxSpinnerModule,
        NgxPaginationModule
    ],
    declarations: [
        CityMasterComponent],
    exports: [],
    providers: [MasterService]
})

export class CityModule {
}
