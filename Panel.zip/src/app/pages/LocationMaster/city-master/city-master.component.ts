import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { MasterService } from '../../../services/master.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import 'datatables.net';
import 'datatables.net-bs4';
declare var $: any;

@Component({
  selector: 'app-city-master',
  templateUrl: './city-master.component.html',
  styleUrls: ['./city-master.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CityMasterComponent implements OnInit {
  dataTable: any;
  stateId: any;
  cityArr: any[];
  p: number = 1;

  constructor(public router: Router, private spinner: NgxSpinnerService,
    private toastr: ToastrManager, private _masterService: MasterService, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.getallCity();
    this.dataHide();
  }
 dataHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  getallCity() {
    this.spinner.show();
    this._masterService.AllCity().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.citydataList;
          this.chRef.detectChanges();
          $('#example-table').DataTable({
            "paging": false,
            "bSort": false,
            "info": false
          });
            this.dataShow();
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  isTrueOrFalse(data) {
    if (data == true) {
      return "Active"
    }
    else if (data == false) {
      return "Inactive"
    }
  }
  isNullOrEmpty(data) {
    return (data == undefined || data == null || data == "") ? "NA" : data;
  }
  convertToLocal(data) {
    return (data == undefined || data == null || data == "") ? "NA" : new Date(data * 1000).toLocaleString();
  }
}
