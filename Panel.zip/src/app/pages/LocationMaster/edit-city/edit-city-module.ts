import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EditCityRoutingModule } from '../../LocationMaster/edit-city/edit-city-routing-module';
import { EditCityComponent } from '../../LocationMaster/edit-city/edit-city.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { MasterService } from '../../../services/master.service';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        CommonModule,
        EditCityRoutingModule,
        MenuModule,
        FormsModule,NgxSpinnerModule
    ],
    declarations: [
        EditCityComponent
    ],
    exports: [

    ],
    providers: [MasterService]
})


export class EditCityModule {
}
