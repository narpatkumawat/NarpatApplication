import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MasterService } from '../../../services/master.service';
import { Router, ParamMap, Params, ActivatedRoute } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { City } from '../../../wrappers/city';
import { Subscription } from 'rxjs/Subscription'

declare var $: any;

@Component({
  selector: 'app-edit-city',
  templateUrl: './edit-city.component.html',
  styleUrls: ['./edit-city.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditCityComponent implements OnInit {
  subScription: Subscription;
  id: string;
  cityArr: any;
  stateArr: any[];
  stateId: any;
  isActive: any;
  name: any;
  data: any
  statusList: any;

  constructor(public router: Router, private _activatedRoute: ActivatedRoute, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.cityArr = new City();
  }


  ngOnInit(): void {
    this.fnIsActive();
    this.allState();
    this.subScription = this._activatedRoute.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id')
    });
    if (this.id != "") {
      this.spinner.show();
      this._masterService.getcityById(this.id).subscribe(
        resultArray => {
          if (resultArray.status = 200) {
            this.cityArr = resultArray;
            this.stateId = this.cityArr.stateId;
            this.isActive = this.cityArr.isActive;
            if (this.isActive == true) {
              this.isActive = 1;
            }
            else {
              this.isActive = 0;
            }
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.spinner.hide();
          }
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }

  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  fnIsActive() {
    this.statusList = this.data = [
      {
        "Id": 1,
        "status": "Active"
      },
      {
        "Id": 0,
        "status": "Inactive"
      }
    ]
  }

  updateCity() {
    if (this.cityArr.name == "" || this.cityArr.name == undefined) {
      this.toastr.warningToastr("Please enter city name", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return
    }
    var data = {
      "stateId": this.stateId,
      "name": this.cityArr.name,
      "isactive": this.isActive == 1 ? true : false,
      "id": this.id
    }
    this.spinner.show();
    this._masterService.editCity(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.router.navigate(['/citylist']);
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
}
