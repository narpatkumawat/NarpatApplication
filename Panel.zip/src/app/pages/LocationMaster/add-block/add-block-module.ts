import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AddBlockroutingModule } from '../../LocationMaster/add-block/add-blockrouting-module';
import { AddBlockComponent } from '../../LocationMaster/add-block/add-block.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { MasterService } from '../../../services/master.service';
import { FormsModule} from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        CommonModule,
        AddBlockroutingModule,
        MenuModule,
        FormsModule,NgxSpinnerModule
    ],
    declarations: [
        AddBlockComponent
    ],
    exports: [

    ],
    providers: [MasterService]
})

export class AddBlockModule {
}
