import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MasterService } from '../../../services/master.service';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { Block } from '../../../wrappers/block';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-block',
  templateUrl: './add-block.component.html',
  styleUrls: ['./add-block.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AddBlockComponent implements OnInit {

  stateArr: any[];
  cityArr: any[];
  cityId: any;
  block: any;
  name: any;

  constructor(public router: Router, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.block = new Block();
  }

  ngOnInit() {
    this.allState();
  }

  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allCity(stateId) {
    if (stateId == "undefined") {
      stateId = 0;
      this.block.cityId = undefined
    }
    this.spinner.show();
    this._masterService.getAllCity(stateId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.cityList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  saveBlock(form: NgForm) {
    var data = form.value;
    this.spinner.show();
    this._masterService.addBlock(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.block = new Block();
          form.resetForm();
          this.router.navigate(['/blocklist']);
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

}
