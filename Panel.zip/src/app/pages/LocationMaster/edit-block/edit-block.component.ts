import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MasterService } from '../../../services/master.service';
import { Router, ParamMap, Params, ActivatedRoute } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { Block } from '../../../wrappers/block';
import { Subscription } from 'rxjs/Subscription'
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-edit-block',
  templateUrl: './edit-block.component.html',
  styleUrls: ['./edit-block.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditBlockComponent implements OnInit {
  subScription: Subscription;
  stateArr: any[];
  cityArr: any[];
  cityId: any;
  stateId: any;
  name: any;
  id: string;
  blockArr: any;
  isActive: any;
  data: any;
  statusList: any;

  constructor(public router: Router, private _activatedRoute: ActivatedRoute, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager) {

    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.blockArr = new Block();

  }

  ngOnInit() {
   // this.cityId = 0;
    this.fnIsActive();
    this.allState();
    this.subScription = this._activatedRoute.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id')
    });
    if (this.id != "") {
      this.spinner.show();
      this._masterService.getblockBy(this.id).subscribe(
        resultArray => {
          if (resultArray.status = 200) {
            this.blockArr = resultArray;
            this.stateId = this.blockArr.stateid;
            this.cityId = this.blockArr.cityId;
            this.isActive = this.blockArr.isActive;
            if (this.isActive == true) {
              this.blockArr.isActive = 1;
            }
            else {
              this.blockArr.isActive = 0;
            }
            this.allCity(this.stateId);
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allCity(stateId) {
    if (this.id != "") {
      //this.cityId = 0;
    }
    this.spinner.show();
    this._masterService.getAllCity(stateId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.cityList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  fnIsActive() {
    this.statusList = this.data = [
      {
        "Id": 1,
        "status": "Active"
      },
      {
        "Id": 0,
        "status": "Inactive"
      }
    ]
  }
  updateBlock() {
    if (this.cityId == "" || this.cityId == 0) {
      this.toastr.warningToastr("Please select city name", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return
    }
    var data = {
      "name": this.blockArr.name,
      "cityId": this.cityId,
      "id": this.id,
      "isActive": this.blockArr.isActive == 1 ? true : false
    }
    this.spinner.show();
    this._masterService.editBlock(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.router.navigate(['/blocklist']);
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
}
