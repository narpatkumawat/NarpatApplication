import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditBlockComponent } from '../../LocationMaster/edit-block/edit-block.component';

const routes: Routes = [
    { path: '', component: EditBlockComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EditBlockRoutingModule {
}
