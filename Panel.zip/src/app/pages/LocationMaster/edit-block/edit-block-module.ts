import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EditBlockRoutingModule } from '../../LocationMaster/edit-block/edit-block-routing-module';
import { EditBlockComponent } from '../../LocationMaster/edit-block/edit-block.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { MasterService } from '../../../services/master.service';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        CommonModule,
        EditBlockRoutingModule,
        MenuModule,
        FormsModule,NgxSpinnerModule
    ],
    declarations: [
        EditBlockComponent
    ],
    exports: [],
    providers: [MasterService]
})

export class EditBlockModule {
}
