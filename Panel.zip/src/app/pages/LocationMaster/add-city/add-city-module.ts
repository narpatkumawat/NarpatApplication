import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AddCityRoutingModule } from '../../LocationMaster/add-city/add-city-routing-module';
import { AddCityComponent } from '../../LocationMaster/add-city/add-city.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { MasterService } from '../../../services/master.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

@NgModule({
    imports: [
        CommonModule,
        AddCityRoutingModule,
        MenuModule,
        NgxSpinnerModule,
        FormsModule
    ],
    declarations: [
        AddCityComponent
    ],
    exports: [],
    providers: [MasterService]
})

export class AddCityModule {
}
