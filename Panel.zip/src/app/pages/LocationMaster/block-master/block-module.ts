import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BlockRoutingModule } from '../../LocationMaster/block-master/block-routing-module';
import { BlockMasterComponent } from '../../LocationMaster/block-master/block-master.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { MasterService } from '../../../services/master.service';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        CommonModule,
        BlockRoutingModule,
        MenuModule,
        FormsModule,
        NgxSpinnerModule,
        NgxPaginationModule,
    ],
    declarations: [
        BlockMasterComponent
    ],
    exports: [

    ],
    providers: [MasterService]
})

export class BlockModule {
}
