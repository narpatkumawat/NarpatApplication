import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MasterService } from '../../../services/master.service';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { City } from '../../../wrappers/city';
import 'datatables.net';
import 'datatables.net-bs4';
declare var $: any;

@Component({
  selector: 'app-block-master',
  templateUrl: './block-master.component.html',
  styleUrls: ['./block-master.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BlockMasterComponent implements OnInit {
  dataTable: any;
  stateId: any;
  blockArr: any[]
  p: number = 1;

  constructor(public router: Router, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.allBlock();
    this.dataHide();
  }
 dataHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  allBlock() {
    this.spinner.show();
    this._masterService.getAllBlockList().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.blockArr = resultArray.blockdataList;
          this.chRef.detectChanges();
          $('#example-table').DataTable({
            "paging": false,
            "bSort": false,
            "info": false
          });
            this.dataShow();
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  isTrueOrFalse(data) {
    if (data == true) {
      return "Active"
    }
    else if (data == false) {
      return "Inactive"
    }
  }

  isNullOrEmpty(data) {
    return (data == undefined || data == null || data == "") ? "NA" : data;
  }
  convertToLocal(data) {
    return (data == undefined || data == null || data == "") ? "NA" : new Date(data * 1000).toLocaleString();
  }
}
