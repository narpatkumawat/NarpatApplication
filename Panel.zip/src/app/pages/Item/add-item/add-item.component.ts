import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { ItemService } from '../../../services/item.service';
import { Item } from '../../../wrappers/item';


@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AddItemComponent implements OnInit {
  items: any;
  propriterId: any;
  propriterArr: any[];
  isImageUpload: any;
  imageChangedEvent: any;
  image: any;
  imageShow: any = '';

  constructor(public router: Router, private spinner: NgxSpinnerService, private _itemService: ItemService,
    private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.items = new Item();
  }
  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.allpropriter();
  }

  uploadImageChange(event) {
    if (typeof (FileReader) !== 'undefined') {
      var dvPreview = document.getElementById('dvPreviewImage');
      dvPreview.innerHTML = '';
      var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
      for (var i = 0; i < event.target.files.length; i++) {
        var file = event.target.files[i];
        var count = 0;
        if (regex.test(file.name.toLowerCase())) {
          this.image = file;
          this.isImageUpload = true;
          this.imageChangedEvent = event;
          var reader = new FileReader();
          reader.onload = () => {
            var img = new Image();
            img.src = reader.result.toString();
            img.onload = function () {
            };
            dvPreview.innerHTML = "<img class='img-responsive rounded-circle' src='" + reader.result + "' style='margin-left: 130px; margin-top: -72px;width:30%;height:20%;' />";
          };
          reader.readAsDataURL(file);
        } else {
          alert(file.name + 'is not a valid image file.');
          return false;
        }
      }
    } else {
      alert('This browser does not support HTML5 FileReader.');
    }
  }
  allpropriter() {
    this.spinner.show();
    this._itemService.getallpropriter().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.propriterArr = resultArray.propList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  saveItem() {
    if (this.items.itemName == "" || this.items.itemName == undefined) {
      this.toastr.warningToastr("Please enter item name", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.items.Quantity == "" || this.items.Quantity == undefined) {
      this.toastr.warningToastr("Please enter quantity", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.items.mrp == "" || this.items.mrp == undefined) {
      this.toastr.warningToastr("Please enter mrp", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.propriterId == 0 || this.propriterId == undefined) {
      this.toastr.warningToastr("Please select propriter", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.image == "" || this.image == undefined) {
      this.toastr.warningToastr("Please select image", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else {
      var data = new FormData();
      data.append('propriterId', this.propriterId);
      data.append('itemname', this.items.itemName);
      data.append('quantity', this.items.Quantity);
      data.append('mrp', this.items.mrp);
      data.append('image', this.image);
      data.append('offer', this.items.offer);

      this.spinner.show();
      this._itemService.addItem(data).subscribe(
        resultArray => {
          if (resultArray.status == 200) {
            this.toastr.successToastr(resultArray.message, 'Success!', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.router.navigate(['/itemlist']);
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.spinner.hide();
          }
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
}
