import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AddItemRoutingModule } from '../../Item/add-item/add-item-routing-module';
import { AddItemComponent } from '../../Item/add-item/add-item.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { ItemService } from '../../../services/item.service';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        CommonModule,
        AddItemRoutingModule,
        MenuModule, FormsModule,NgxSpinnerModule
    ],
    declarations: [
        AddItemComponent
    ],
    exports: [

    ],
    providers: [ItemService]
})
export class AddItemModule {
}
