import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs/Subscription'
import { Router, ParamMap, Params, ActivatedRoute } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { ItemService } from '../../../services/item.service';
import { Item } from '../../../wrappers/item';

@Component({
  selector: 'app-edit-item',
  templateUrl: './edit-item.component.html',
  styleUrls: ['./edit-item.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class EditItemComponent implements OnInit {
  subScription: Subscription;
  propriterArr: any[];
  items: any;
  isImageUpload: any;
  imageChangedEvent: any;
  image: any;
  imageShow: any = '';
  id: any;
  propriterId: any;
  offer: any;
  data: any;
  statusList: any;
  isActive: any;
  imgURL: any;

  constructor(public router: Router, private _itemService: ItemService, private _activatedRoute: ActivatedRoute, private spinner: NgxSpinnerService,
    private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.items = new Item();
  }
  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit(): void {
    this.fnIsActive();
    this.subScription = this._activatedRoute.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id')
    });
    if (this.id != "") {
      this.spinner.show();
      this._itemService.getItemsbyId(this.id).subscribe(
        resultArray => {
          if (resultArray.status = 200) {
            this.items = resultArray;
            this.propriterId = this.items.propriterId;
            this.items.isActive = this.items.isActive;
            if (this.items.isActive == true) {
              this.items.isActive = 1;
            }
            else {
              this.items.isActive = 0;
            }
            if (this.items.image != '') {
              this.imgURL = this.items.image;
            }
            this.allpropriter();
          }
        });
      this.spinner.hide();
    }
  }
  updateItem() {
    if (this.propriterId == 0 || this.propriterId == undefined) {
      this.toastr.warningToastr("Please select propriter", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.items.itemName == "" || this.items.itemName == undefined) {
      this.toastr.warningToastr("Please enter item name", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.items.Quantity == "" || this.items.Quantity == undefined) {
      this.toastr.warningToastr("Please enter quantity", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.items.mrp == "" || this.items.mrp == undefined) {
      this.toastr.warningToastr("Please enter mrp", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else {
      this.isActive = this.items.isActive == 1 ? true : false
      var data = new FormData();
      data.append('propriterId', this.propriterId);
      data.append('itemName', this.items.itemName);
      data.append('Quantity', this.items.Quantity);
      data.append('mrp', this.items.mrp);
      data.append('image', this.image);
      data.append('offer', this.items.offer);
      data.append('isActive', this.isActive);
      data.append('id', this.id);

      this.spinner.show();
      this._itemService.editItems(data).subscribe(
        resultArray => {
          if (resultArray.status == 200) {
            this.toastr.successToastr(resultArray.message, 'Success!', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.router.navigate(['/itemlist']);
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
  allpropriter() {
    this.spinner.show();
    this._itemService.getallpropriter().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.propriterArr = resultArray.propList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  fnIsActive() {
    this.statusList = this.data = [
      {
        "Id": 1,
        "status": "Active"
      },
      {
        "Id": 0,
        "status": "Inactive"
      }
    ]
  }
  uploadImageChange(event) {
    if (typeof (FileReader) !== 'undefined') {
      var dvPreview = document.getElementById('dvPreviewImage');
      dvPreview.innerHTML = '';
      var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
      for (var i = 0; i < event.target.files.length; i++) {
        var file = event.target.files[i];
        if (regex.test(file.name.toLowerCase())) {
          this.image = file;
          this.isImageUpload = true;
          this.imageChangedEvent = event;
          var reader = new FileReader();
          reader.onload = () => {
            var img = new Image();
            img.src = reader.result.toString();
            img.onload = (_event) => {

              this.imgURL = reader.result;
            };
          };
          reader.readAsDataURL(file);
        } else {
          alert(file.name + 'is not a valid image file.');
          return false;
        }
      }
    } else {
      alert('This browser does not support HTML5 FileReader.');
    }
  }
}
