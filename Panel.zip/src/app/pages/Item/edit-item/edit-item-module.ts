import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EditItemRoutingModule } from '../../Item/edit-item/edit-item-routing-module';
import { EditItemComponent } from '../../Item/edit-item/edit-item.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { ItemService } from '../../../services/item.service';
import {FormsModule} from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        CommonModule,
        EditItemRoutingModule,
        MenuModule,
        FormsModule,NgxSpinnerModule
    ],
    declarations: [EditItemComponent],
    exports: [ ],
    providers: [ItemService]
})
export class EditItemModule {
}
