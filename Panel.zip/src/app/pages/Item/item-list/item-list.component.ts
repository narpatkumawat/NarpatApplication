import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { ItemService } from '../../../services/item.service';
import 'datatables.net';
import 'datatables.net-bs4';
import { Item } from '../../../wrappers/item';
declare var $: any;

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {
  itemsArr: any[];
  propriterId: any;
  propriterArr: any[];
  dataTable: any;
  itemName: any;
  status: any;
  displayImage: any;

  constructor(public router: Router, private spinner: NgxSpinnerService, private _itemService: ItemService,
    private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }

  }

  ngOnInit() {
    this.allpropriter();
    this.dataHide();
  }
  dataHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  openImageAlert(showsImage) {
    var image = document.getElementById('openModel')
    image.style.display = 'block'
    this.displayImage = showsImage;
  }
  hideimage() {
    var model = document.getElementById('openModel')
    model.style.display = 'none'
  }
  allpropriter() {
    this.spinner.show();
    this._itemService.getallpropriter().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.propriterArr = resultArray.propList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  itemSearch() {
    if (this.propriterId == undefined && this.itemName == undefined && this.status == undefined) {
      this.toastr.warningToastr("Please select any value ", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    var data = {
      "propriterId": this.propriterId == undefined ? 0 : this.propriterId,
      "itemName": this.itemName == undefined ? "" : this.itemName,
      "status": this.status == undefined ? 3 : this.status,
    }
    this.spinner.show();
    this._itemService.searchItems(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.itemsArr = resultArray.itemsearchList;
          this.chRef.detectChanges();
          $('#example-table').DataTable({
            "paging": false,
            "bSort": false,
            "info": false,
            "bDestroy": true
          });
          this.dataShow();
        }
        else {
          this.itemsArr = [];
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  isTrueOrFalse(data) {
    if (data == true) {
      return "Active"
    }
    else if (data == false) {
      return "Inactive"
    }
  }

  isNullOrEmpty(data) {
    return (data == undefined || data == null || data == "") ? "NA" : data;
  }
}
