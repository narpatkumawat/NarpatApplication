import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ItemService } from '../../../services/item.service';
import { ItemlistRoutingModule } from '../../Item/item-list/itemlist-routing-module';
import { ItemListComponent } from '../../Item/item-list/item-list.component';
import { MenuModule } from '../../../components/menu/menu.module';
import {FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        CommonModule,
        ItemlistRoutingModule,
        MenuModule,
        FormsModule,
        NgxSpinnerModule,
        NgxPaginationModule
    ],
    declarations: [
        ItemListComponent
    ],
    exports: [],
    providers: [ItemService]
})
export class ItemlistModule {
}
