import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {RouterModule, Routes } from '@angular/router';

import { ErrorRoutingModule } from './error-routing.module';
import { ErrorComponent } from './error.component';
import { MenuModule} from '../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {AdminService} from '../../services/admin.service';


@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        ErrorRoutingModule,
        MenuModule
    ],
    declarations: [
        ErrorComponent
    ],
    exports:[
       
    ],
    providers:[
        AdminService
    ]
})
export class ErrorModule {
}