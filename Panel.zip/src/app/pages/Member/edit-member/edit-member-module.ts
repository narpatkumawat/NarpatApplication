import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditMemberRoutingModule } from '../../Member/edit-member/edit-member-routing-module';
import { EditMemberComponent } from '../../Member/edit-member/edit-member.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        EditMemberRoutingModule,
        MenuModule
    ],
    declarations: [
        EditMemberComponent
    ],
    exports: [

    ],
    providers: [

    ]
})


export class EditMemberModule {
}
