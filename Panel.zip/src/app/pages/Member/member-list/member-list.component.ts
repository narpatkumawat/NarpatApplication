import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { MasterService } from '../../../services/master.service';
import { MemberService } from '../../../services/member.service';
import 'datatables.net';
import 'datatables.net-bs4';
declare var $: any;

@Component({
  selector: 'app-member-list',
  templateUrl: './member-list.component.html',
  styleUrls: ['./member-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MemberListComponent implements OnInit {
  dataTable: any;
  stateArr: any[];
  cityArr: any[];
  blockArr: any[];
  memberArr: any[];
  stateId: any;
  cityId: any;
  blockId: any;
  status: any;
  statusU: any;
  statusId: any;
  p: number = 1;

  constructor(public router: Router, private _masterService: MasterService,
    private _memberService: MemberService, private chRef: ChangeDetectorRef,
    private toastr: ToastrManager, private spinner: NgxSpinnerService) {

    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
  }


  ngOnInit() {
    this.allState();
    this.divHide();
  }
  divHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  divShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  showAlert(Id, statusM) {
    var model = document.getElementById('myModal')
    model.style.display = 'block'
    this.statusId = Id;
    this.statusU = statusM;
  }

  updateStatus() {
    var data = {
      "status": this.statusU,
      "id": this.statusId
    }
    this.spinner.show();
    this._memberService.updateStatus(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.hideAlert();
          this.memberSearch();
        }
      });
    this.spinner.hide();
  }

  hideAlert() {
    var model = document.getElementById('myModal')
    model.style.display = 'none'
  }

  memberSearch() {
    var data = {
      "stateId": this.stateId,
      "cityId": this.cityId,
      "blockId": this.blockId,
      "status": this.status == undefined ? 3 : this.status
    }
    this.spinner.show();
    this._memberService.memberSearch(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.memberArr = resultArray.membersearchList;
          this.chRef.detectChanges();
          $('#example-table').DataTable({
            "paging": false,
            "bSort": false,
            "info": false,
            "bDestroy": true
          });
          this.divShow();
        }
        else {
          this.memberArr = []
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allCity(stateId) {
    if (stateId == undefined) {
      stateId = 0;
    }
    this.spinner.show();
    this._masterService.getAllCity(stateId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.cityList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  allblockbyId(cityId) {
    if (cityId == undefined) {
      cityId = 0;
    }
    this.spinner.show();
    this._masterService.getAllBlock(cityId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.blockArr = resultArray.blockList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  isNullOrEmpty(data) {
    return (data == undefined || data == null || data == "") ? "NA" : data;
  }
  statusData(status) {
    if (status == 1) {
      return "Active"
    }
    else if (status == 0) {
      return "InActive"
    }
    else if (status == 2) {
      return "Pending"
    }
  }
}
