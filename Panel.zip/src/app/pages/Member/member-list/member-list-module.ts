import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MemberListRoutingModule } from '../../Member/member-list/member-list-routing-module';
import { MemberListComponent } from '../../Member/member-list/member-list.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MasterService } from '../../../services/master.service';
import { MemberService } from '../../../services/member.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        MemberListRoutingModule,
        MenuModule, NgxSpinnerModule,
        NgxPaginationModule
    ],
    declarations: [
        MemberListComponent
    ],
    exports: [],
    providers: [MasterService, MemberService]
})


export class MemberListModule {
}
