import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddMemberRoutingModule } from '../../Member/add-member/add-member-routing-module';
import { AddMemberComponent } from '../../Member/add-member/add-member.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        AddMemberRoutingModule,
        MenuModule
    ],
    declarations: [
        AddMemberComponent
    ],
    exports: [

    ],
    providers: [

    ]
})


export class AddMemberModule {
}
