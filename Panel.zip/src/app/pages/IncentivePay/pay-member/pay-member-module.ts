import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PayMemberRoutingModule } from '../pay-member/pay-member-routing-module';
import { PayMemberComponent } from '../pay-member/pay-member.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AdminService } from '../../../services/admin.service';
import { LedgerService } from '../../../services/ledger.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
    imports: [
        CommonModule,FormsModule,
        PayMemberRoutingModule,
        MenuModule, NgxSpinnerModule
    ],
    declarations: [
        PayMemberComponent
    ],
    exports: [],
    providers: [AdminService, LedgerService]
})
export class PayMemberModule {
}
