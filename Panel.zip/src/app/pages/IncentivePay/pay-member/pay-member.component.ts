import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LedgerService } from '../../../services/ledger.service';
import { Payformember } from '../../../wrappers/payformember';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-pay-member',
  templateUrl: './pay-member.component.html',
  styleUrls: ['./pay-member.component.css']
})
export class PayMemberComponent implements OnInit {
  memberpayArr: any[];
  Memberpay: Payformember;
  Totalbal: number;
  constructor(public router: Router, private _ledgerService: LedgerService, private spinner: NgxSpinnerService, private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.Memberpay = new Payformember();
  }
  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }

  ngOnInit() {
    this.dataHide();
  }

  dataHide() {
    var data = document.getElementById('bank')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('bank')
    data.style.display = 'block'
  }



  varifyMemberData() {
    var data = {
      "membercode": this.Memberpay.membercode
    }
    this.spinner.show();
    this._ledgerService.VerifyMemberData(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.memberpayArr = resultArray.recordList;
          sessionStorage.setItem("ACNo", this.memberpayArr[0].accountNo);
          this.Totalbal = this.memberpayArr[0].Balance;
          this.dataShow();
        }
        else {
          this.dataHide();
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  IncentivePay() {
    var data = {
      "transactionId": this.Memberpay.transactionId,
      "amount": this.Memberpay.amount,
      "membercode": this.Memberpay.membercode,
      "accountNo": sessionStorage.getItem("ACNo")
    }
    if (data.amount == undefined || data.amount == 0) {
      this.toastr.warningToastr('Please enter valid amount', '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else if (data.amount > this.Totalbal) {
      this.toastr.warningToastr('Incentive amount, should be less than and equale to balance amount !!', '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else {
      this.spinner.show();
      this._ledgerService.PayMemberIncentive(data).subscribe(
        resultArray => {
          if (resultArray.status == 200) {
            this.toastr.successToastr(resultArray.message, 'Success!', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.Memberpay.transactionId = null;
            this.Memberpay.amount = null;
            this.Memberpay.membercode = null;
            // this.deposit.ToDate=null
            this.dataHide();

          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            // this.deposit.ToDate=null
            this.dataHide();
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
}