import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LimitinceaseRoutingModule } from '../limit-increase/limitincease-routing-module';
import { LimitIncreaseComponent } from './limit-increase.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AdminService } from '../../../services/admin.service';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { LedgerService } from '../../../services/ledger.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    imports: [
        CommonModule, FormsModule,
        LimitinceaseRoutingModule,
        MenuModule, NgxSpinnerModule, BsDatepickerModule.forRoot()

    ],
    declarations: [
        LimitIncreaseComponent
    ],
    exports: [],
    providers: [AdminService, LedgerService]
})
export class LimitinceaseModule {
}
