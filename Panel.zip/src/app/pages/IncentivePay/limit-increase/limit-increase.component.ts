import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LedgerService } from '../../../services/ledger.service';
import { Payformember } from '../../../wrappers/payformember';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-limit-increase',
  templateUrl: './limit-increase.component.html',
  styleUrls: ['./limit-increase.component.css']
})
export class LimitIncreaseComponent implements OnInit {
  memberpayArr: any[];
  Memberpay: Payformember;
  DenomationArr: any[];
  TotalBal: number;
  p: number = 1;

  constructor(public router: Router, private _ledgerService: LedgerService, private spinner: NgxSpinnerService, private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.Memberpay = new Payformember();
  }
  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }

  ngOnInit() {
    this.DenomationAmt();
    this.dataHide();
  }

  dataHide() {
    var data = document.getElementById('bank')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('bank')
    data.style.display = 'block';
  }
  DenomationAmt() {
    this.spinner.show();
    this._ledgerService.getDenomationAmount().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.DenomationArr = resultArray.amountList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  varifyMemberData() {
    var data = {
      "membercode": this.Memberpay.membercode
    }
    this.spinner.show();
    this._ledgerService.VerifyMemberData(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.memberpayArr = resultArray.recordList;
          sessionStorage.setItem("ACNo", this.memberpayArr[0].accountNo);
          // sessionStorage.setItem("closeamt", this.memberpayArr[0].Balance);
          this.TotalBal = this.memberpayArr[0].Balance;
          this.dataShow();
        }
        else {
          this.dataHide();
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  LimitIncrease() {
    var data = {
      "amount": this.Memberpay.amount,
      "membercode": this.Memberpay.membercode,
      "ToDate": this.Memberpay.ToDate,
      "accountNo": sessionStorage.getItem("ACNo")
    }
    if (this.Memberpay.membercode == undefined) {
      this.toastr.warningToastr('Please enter memberId !!', '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else if (data.amount == undefined || data.amount == 0 || data.accountNo == "") {
      this.toastr.warningToastr('Please select denomation amount !!', '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else if (data.ToDate == undefined) {
      this.toastr.warningToastr('Please enter validity date !!', '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else if (data.amount > this.TotalBal) {
      this.toastr.warningToastr('Please select  denomation amount, should be less than and equale to balance amount !!', '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else {
      this.spinner.show();
      this._ledgerService.LimitIncrease(data).subscribe(
        resultArray => {
          if (resultArray.status == 200) {
            this.toastr.successToastr(resultArray.message, 'Success!', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.Memberpay.transactionId = null;
            this.Memberpay.amount = null;
            this.Memberpay.membercode = null;
            // this.deposit.ToDate=null
            this.dataHide();
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.Memberpay.transactionId = null;
            this.Memberpay.amount = null;
            this.Memberpay.membercode = null;
            // this.deposit.ToDate=null
            this.dataHide();
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
}
