import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PayCompanyRoutingModule } from '../pay-company/pay-company-routing-module';
import { PayCompanyComponent } from '../pay-company/pay-company.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AdminService } from '../../../services/admin.service';
import {LedgerService} from '../../../services/ledger.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
    imports: [
        CommonModule,FormsModule,
        PayCompanyRoutingModule,
        MenuModule,NgxSpinnerModule,BsDatepickerModule.forRoot()
    ],
    declarations: [
        PayCompanyComponent
    ],
    exports: [],
    providers: [AdminService,LedgerService]
})
export class PayCompanyModule {
}
