import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LedgerService } from '../../../services/ledger.service';
import { Payforcompany } from '../../../wrappers/payforcompany';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-pay-company',
  templateUrl: './pay-company.component.html',
  styleUrls: ['./pay-company.component.css']
})
export class PayCompanyComponent implements OnInit {
  PayCompArr: any[];
  Paytocompany: Payforcompany;

  constructor(public router: Router, private _ledgerService: LedgerService, private spinner: NgxSpinnerService, private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.Paytocompany = new Payforcompany();
  }

  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }

  ngOnInit() {
  }

  PayToCompany(form: NgForm) {
    this.spinner.show();
    var data = form.value;
    this._ledgerService.PayToCompanyAmount(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.Paytocompany = new Payforcompany();
          form.resetForm();
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
}
