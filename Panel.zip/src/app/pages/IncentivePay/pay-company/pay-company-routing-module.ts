import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PayCompanyComponent } from '../pay-company/pay-company.component';

const routes: Routes = [
    { path: '', component: PayCompanyComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
export class PayCompanyRoutingModule {
}
