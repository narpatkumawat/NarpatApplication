import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UserlistRoutingModule } from './userlist-routing-module';
import { UserListComponent } from './user-list.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        UserlistRoutingModule,
        MenuModule,
        NgxSpinnerModule,
        NgxPaginationModule
    ],
    declarations: [
        UserListComponent
    ],
    exports: [
    ],
    providers: [AdminService]
})

export class UserListModule {
}
