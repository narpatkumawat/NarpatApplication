import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { AdminService } from '../../../services/admin.service';
import 'datatables.net';
import 'datatables.net-bs4';
declare var $: any;

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class UserListComponent implements OnInit {
  dataTable: any;
  userArry: any[];
  p: number = 1;
  
  constructor(public router: Router, private _userMaster: AdminService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.getUsers();
    this.dataHide();
  }
  dataHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  getUsers() {
    this.spinner.show();
    this._userMaster.getAllUsers().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.userArry = resultArray.userList;
          this.chRef.detectChanges();
          $('#example-table').dataTable({
            "paging": false,
            "bSort": false,
            "info": false
          });
            this.dataShow();
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  isTrueOrFalse(data) {
    if (data == true) {
      return "Active"
    }
    else if (data == false) {
      return "Inactive"
    }
  }
  isNullOrEmpty(data) {
    return (data == undefined || data == null || data == "") ? "NA" : data;
  }
  typeRole(data) {
    if (data == 1) {
      return "Admin"
    }
    else if (data == 2) {
      return "SuperAdmin"
    }
    else if (data == 3) {
      return "User"
    }
  }
}
