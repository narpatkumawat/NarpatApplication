import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EdituserRoutingModule } from './edituser-routing-module';
import { EditUserComponent } from './edit-user.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        EdituserRoutingModule,
        MenuModule,
        NgxSpinnerModule
    ],
    declarations: [
        EditUserComponent
    ],
    exports: [

    ],
    providers: [AdminService]
})

export class EditUserModule {
}
