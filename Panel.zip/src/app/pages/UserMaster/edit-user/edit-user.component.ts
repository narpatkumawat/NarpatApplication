import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ParamMap, Params, ActivatedRoute } from '@angular/router'
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { AdminService } from '../../../services/admin.service';
import { Admin } from '../../../wrappers/admin';
import { Subscription } from 'rxjs/Subscription'

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditUserComponent implements OnInit {
  subScription: Subscription;
  users: any;
  data: any;
  statusList: any;
  id: string;
  isActive: any;
  constructor(public router: Router, private _adminService: AdminService, private _activatedRoute: ActivatedRoute, private spinner: NgxSpinnerService,
    private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.users = new Admin();
  }
  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.fnIsActive();
    this.subScription = this._activatedRoute.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id')
    });
    if (this.id != "") {

      this.spinner.show();
      this._adminService.getByuserId(this.id).subscribe(
        resultArray => {
          if (resultArray.status = 200) {
            this.users = resultArray;
            this.users.isActive = this.users.isActive;
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }

  updateUser() {
    var data = {
      "name": this.users.name,
      "mobile": this.users.mobile,
      "email": this.users.email,
      "password": this.users.password,
      "roleType": this.users.roleType,
      "isActive": this.users.isActive,
      "id": this.users.id
    }
    this.spinner.show();
    this._adminService.updateUser(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.router.navigate(['/userlist']);
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });

  }
  fnIsActive() {
    this.statusList = this.data = [
      {
        "Id": 1,
        "isActive": "Active"
      },
      {
        "Id": 0,
        "isActive": "Inactive"
      }
    ]
  }
}
