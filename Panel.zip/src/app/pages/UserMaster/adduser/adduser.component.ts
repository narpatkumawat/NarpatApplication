import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { AdminService } from '../../../services/admin.service';
import { Admin } from '../../../wrappers/admin';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class AdduserComponent implements OnInit {
  users: Admin;

  constructor(public router: Router, private _adminService: AdminService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.users = new Admin();
  }

  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }

  ngOnInit() {
  }

  addUser(form: NgForm) {
    if (this.users.password != this.users.confirmPassword) {
      this.toastr.warningToastr("Password and confirm password do not match.", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else {
      var data = form.value;
      this.spinner.show();
      this._adminService.saveUser(data).subscribe(
        resultArray => {
          if (resultArray.status == 200) {
            this.toastr.successToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.users = new Admin();
            form.resetForm();
            this.router.navigate(['/userlist']);
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
}