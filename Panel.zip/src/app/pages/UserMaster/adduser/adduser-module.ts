
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AdduserRoutingModule } from './adduser-routing-module';
import { AdduserComponent } from './adduser.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        AdduserRoutingModule,
        MenuModule,NgxSpinnerModule
    ],
    declarations: [
        AdduserComponent
    ],
    exports: [],
    providers: [AdminService]
})

export class AdduserModule {
}
