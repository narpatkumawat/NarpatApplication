import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IncentiveRoutingModule } from '../member-incentive/incentive-routing-module';
import { MemberIncentiveComponent } from '../member-incentive/member-incentive.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AdminService } from '../../../services/admin.service';
import { MemberService } from '../../../services/member.service';
import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
    imports: [
        CommonModule,
        IncentiveRoutingModule, FormsModule,
        MenuModule, NgxSpinnerModule, BsDatepickerModule.forRoot(),
        NgxPaginationModule
    ],
    declarations: [
        MemberIncentiveComponent
    ],
    exports: [],
    providers: [AdminService, MemberService]
})
export class IncentiveModule {
}
