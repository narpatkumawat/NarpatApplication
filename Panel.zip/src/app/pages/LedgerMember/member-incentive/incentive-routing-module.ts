import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MemberIncentiveComponent } from '../member-incentive/member-incentive.component';

const routes: Routes = [
    { path: '', component: MemberIncentiveComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
export class IncentiveRoutingModule {
}
