import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { MemberService } from '../../../services/member.service';
import { MemberIncLedger } from '../../../wrappers/member-inc-ledger';
import 'datatables.net';
import 'datatables.net-bs4';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;

@Component({
  selector: 'app-member-incentive',
  templateUrl: './member-incentive.component.html',
  styleUrls: ['./member-incentive.component.css']
})
export class MemberIncentiveComponent implements OnInit {
  dataTable: any;
  incentiveLedgerArr: MemberIncLedger[];
  memberIncetive: MemberIncLedger;
  p: number = 1;

  constructor(public router: Router, private _memberService: MemberService, private toastr: ToastrManager, private chRef: ChangeDetectorRef, private spinner: NgxSpinnerService) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.memberIncetive = new MemberIncLedger();
  }

  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }

  ngOnInit() {
    this.spinner.hide();
    this.dataHide();
    this.divHide();
  }
  divHide() {
    var dataDisplay = document.getElementById('DisPage')
    dataDisplay.style.display = 'none'
  }
  divShow() {
    var dataDisplay = document.getElementById('DisPage')
    dataDisplay.style.display = 'block'
  }
  dataHide() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "none";
  }
  dataShow() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "block";
  }

  searchMemberIncLedger() {
    var data = {
      "membercode": this.memberIncetive.membercode,
      "fromDate": this.memberIncetive.FromDate,
      "toDate": this.memberIncetive.ToDate
    }
    this.spinner.show();
    this._memberService.memberIncLedger(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.incentiveLedgerArr = resultArray.incentiveList;
          this.chRef.detectChanges();
          $('#example-table').DataTable(
            {
              "paging": false,
              "bSort": false,
              "info": false,
              "bDestroy": true
            });
          this.divShow();
          this.dataShow();
        }
        else {
          this.dataHide();
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
        this.dataHide();
      });
    this.spinner.hide();
  }
}
