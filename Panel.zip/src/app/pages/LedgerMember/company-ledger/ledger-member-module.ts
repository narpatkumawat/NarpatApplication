import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LedgerMemberRoutingModule } from '../company-ledger/ledger-member-routing-module';
import { CompanyLedgerComponent } from '../company-ledger/company-ledger.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AdminService } from '../../../services/admin.service';
import {LedgerService} from '../../../services/ledger.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
    imports: [
        CommonModule,FormsModule,
        LedgerMemberRoutingModule,
        MenuModule, NgxSpinnerModule,
        BsDatepickerModule.forRoot(),
        NgxPaginationModule
    ],
    declarations: [
        CompanyLedgerComponent
    ],
    exports: [],
    providers: [AdminService, LedgerService]
})
export class LedgerMemberModule {
}
