import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { LedgerService } from '../../../services/ledger.service';
import { Bankbalance } from '../../../wrappers/bankbalance';
import { ToastrManager } from 'ng6-toastr-notifications';
import 'datatables.net';
import 'datatables.net-bs4';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;
@Component({
  selector: 'app-company-ledger',
  templateUrl: './company-ledger.component.html',
  styleUrls: ['./company-ledger.component.css']
})
export class CompanyLedgerComponent implements OnInit {
  dataTable: any;
  balancesheetArr: any[];
  balancesheet: Bankbalance;
  p: number = 1;

  constructor(public router: Router, private _ledgerService: LedgerService, private spinner: NgxSpinnerService, private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.balancesheet = new Bankbalance();
  }
  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.dataHide();
    this.divHide();
  }

  divHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  divShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  dataHide() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "none";
  }

  dataShow() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "block";
  }
  SearchData() {
    var data = {
      "FromDate": this.balancesheet.FromDate,
      "ToDate": this.balancesheet.ToDate
    }
    this.spinner.show()
    this._ledgerService.CompanyLegger(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.balancesheetArr = resultArray.balancesheetList;
          this.chRef.detectChanges();
          $('#example-table').DataTable({
            "paging": false,
            "bSort": false,
            "info": false,
            "bDestroy": true
          });
          this.divShow();
          this.dataShow();
        }
        else {
          this.dataHide();
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide()
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
        this.dataHide()
      });
  }
}
