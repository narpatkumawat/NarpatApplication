import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MemberledgerComponent } from '../memberledger/memberledger.component';

const routes: Routes = [
    { path: '', component: MemberledgerComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
export class LedgerRoutingModule {
}
