import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { MasterService } from '../../../services/master.service';
import { MemberService } from '../../../services/member.service';
import 'datatables.net';
import 'datatables.net-bs4';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;
@Component({
  selector: 'app-memberledger',
  templateUrl: './memberledger.component.html',
  styleUrls: ['./memberledger.component.css']
})
export class MemberledgerComponent implements OnInit {
  dataTable: any;
  memberArr: any[];
  membercode: any;
  p: number = 1;

  constructor(public router: Router, private _memberService: MemberService, private toastr: ToastrManager, private spinner: NgxSpinnerService, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
  }


  ngOnInit() {
    this.dataHide();
    this.divHide();
  }
  divHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  divShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }

  dataHide() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "none";
  }

  dataShow() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "block";
  }
  SearchRecord() {
    var data = {
      "membercode": this.membercode
    }
    this.spinner.show();
    this._memberService.memberLegger(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.memberArr = resultArray.userList;
          this.chRef.detectChanges();
          $('#example-table').DataTable(
            {
              "paging": false,
              "bSort": false,
              "info": false,
              "bDestroy": true
            });
          this.divShow();
          this.dataShow();
        }
        else {
          this.dataHide();
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
        this.dataHide();
      });
  }
  statusData(status) {
    if (status == 1) {
      return "Active"
    }
    else if (status == 0) {
      return "InActive"
    }
    else if (status == 2) {
      return "Pending"
    }
  }
}

