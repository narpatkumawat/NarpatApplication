import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TDSRoutingModule } from '../tdsledger/tdsrouting-module';
import { TDSLedgerComponent } from '../tdsledger/tdsledger.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AdminService } from '../../../services/admin.service';
import { MemberService } from '../../../services/member.service';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        CommonModule,
        TDSRoutingModule,FormsModule,
        MenuModule, NgxSpinnerModule, BsDatepickerModule.forRoot(),
        NgxPaginationModule
    ],
    declarations: [
        TDSLedgerComponent
    ],
    exports: [],
    providers: [AdminService, MemberService]
})
export class TDSModule {
}
