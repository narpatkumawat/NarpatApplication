import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TDSLedgerComponent } from '../tdsledger/tdsledger.component';

const routes: Routes = [
    { path: '', component: TDSLedgerComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class TDSRoutingModule {
}
