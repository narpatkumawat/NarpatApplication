import { Component, OnInit, ChangeDetectorRef, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MemberService } from '../../../services/member.service';
import { TdsLedger } from '../../../wrappers/tds-ledger';
import 'datatables.net';
import 'datatables.net-bs4';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
declare var $: any;

@Component({
  selector: 'app-tdsledger',
  templateUrl: './tdsledger.component.html',
  styleUrls: ['./tdsledger.component.css']
})
export class TDSLedgerComponent implements OnInit {
  dataTable: any;
  tdsLedgerArr: TdsLedger[];
  tdsLedger: TdsLedger;


  constructor(public router: Router, private _memberService: MemberService, private spinner: NgxSpinnerService, private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.tdsLedger = new TdsLedger();
  }

  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.dataHide();
    this.divHide();
  }
  divHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  divShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  TrHide() {
    var data = document.getElementById('PdfHeading');
    data.style.display = "none"
  }
  TrShow() {
    var data = document.getElementById('PdfHeading');
    data.style.display = "block"
  }

  dataHide() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "none"
  }
  dataShow() {
    var data = document.getElementById('example23_wrapper');
    data.style.display = "block"
  }
  searchtdsLedger() {
    var data = {
      "panCard": this.tdsLedger.panCard,
      "FromDate": this.tdsLedger.FromDate,
      "ToDate": this.tdsLedger.ToDate
    }
    this.spinner.show();
    this._memberService.tdsLedger(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.tdsLedgerArr = resultArray.tdsledgerList;
          this.chRef.detectChanges();
          $('#example-table').DataTable({
            "paging": false,
            "bSort": false,
            "info": false,
            "bDestroy": true
          });
          this.divShow();
          this.dataShow();
        }
        else {
          this.dataHide();
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
        this.dataHide();
      });
  }

  isTrueOrFalse(data) {
    if (data == true) {
      return "Active"
    }
    else if (data == false) {
      return "Inactive"
    }
  }

  ExportToPdf() {
    var data = document.getElementById('example-table');
    html2canvas(data).then(canvas => {
      var imgWidth = 185;
      var pageHeight = 295;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var heightLeft = imgHeight;
      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF  
      pdf.setFontSize(10);
      var position = 11;
      pdf.addImage(contentDataURL, 'PNG', 11, position, imgWidth, imgHeight);
      pdf.save('AmarashwameghTds.pdf'); // Generated PDF    
    });
  }
}
