import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { MenuModule } from '../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {AdminService } from '../../services/admin.service'
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        LoginRoutingModule,
        MenuModule,NgxSpinnerModule
    ],
    declarations: [
        LoginComponent
    ],
    exports: [

    ],
    providers: [AdminService]
})
export class LoginModule {
}