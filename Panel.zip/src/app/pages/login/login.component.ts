import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Admin } from '../../wrappers/admin';
import { AdminService } from '../../services/admin.service';
import { NgForm } from '@angular/forms';
declare var $: any;

@Component({
    selector: 'login-page',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LoginComponent {
    admin: Admin;

    constructor(public router: Router, private _adminService: AdminService, private toastr: ToastrManager, private spinner: NgxSpinnerService) {
        window.localStorage.clear();
        this.admin = new Admin();
    }
    ngOnInit() {

    }

    singnIn(form: NgForm) {
        this.spinner.show();
        var body = form.value;
        this._adminService.adminLogin(body).subscribe(
            resultArray => {
                if (resultArray.status == 200) {
                    this.toastr.successToastr(resultArray.message, 'Success!', {
                        position: "bottom-center",
                        toastTimeout: 2000,
                        animate: "slideFromBottom"
                    });
                    window.localStorage.setItem('user', JSON.stringify(resultArray.userLogin));
                    this.admin = new Admin();
                    form.resetForm();
                    this.router.navigate(['/dashboard']);
                }
                else {
                    this.toastr.warningToastr(resultArray.message, '', {
                        position: "bottom-center",
                        toastTimeout: 2000,
                        animate: "slideFromBottom"
                    });
                    this.spinner.hide();
                }
            },
            error => {
                this.toastr.warningToastr(error, '', {
                    position: "bottom-center",
                    toastTimeout: 2000,
                    animate: "slideFromBottom"
                });
                return;
            });
    }
}