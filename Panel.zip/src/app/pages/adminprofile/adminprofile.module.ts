import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AdminProfileRoutingModule } from './adminprofile-routing.module';
import { AdminProfileComponent } from './adminprofile.component';
import { MenuModule } from '../../components/menu/menu.module';
import { AdminService } from '../../services/admin.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
    imports: [
        CommonModule,
        AdminProfileRoutingModule,
        MenuModule,
        FormsModule,
        ReactiveFormsModule,
        NgxSpinnerModule
    ],
    declarations: [
        AdminProfileComponent
    ],
    exports: [

    ],
    providers: [
        AdminService
    ]
})
export class   AdminProfileModule {
}