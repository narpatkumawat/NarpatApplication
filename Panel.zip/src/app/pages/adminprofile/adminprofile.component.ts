import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { Admin } from '../../wrappers/admin';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgForm } from '@angular/forms';
declare var $: any;


@Component({
    selector: 'adminprofile-page',
    templateUrl: './adminprofile.component.html',
    styleUrls: ['./adminprofile.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AdminProfileComponent {

    showloader: boolean = false;
    admin: Admin;
    oldPassword: string;
    newPassword: string;
    confirmPassword: string;
    adminName: any;
    Id: any;
    constructor(public router: Router, private _adminService: AdminService, private toastr: ToastrManager, private spinner: NgxSpinnerService) {
        var user = JSON.parse(window.localStorage.getItem('user')) as Admin;
        this.admin = new Admin();
        debugger
        if (user == undefined || user == null) {
            this.router.navigate(['']);
        }
        else {
            this.admin = user;
            this.adminName = user.name;
            this.Id = user.id
        }

    }
    ngOnInit() {

    }

    // updateProfile() {
    //     if (this.admin.email == "" || this.admin.email == "undefined") {
    //         this.toastr.warningToastr("username or password cann't be blank.", '', {
    //             position: "bottom-center",
    //             toastTimeout: 2000,
    //             animate: "slideFromBottom"
    //         });
    //         return;
    //     }
    //     if (this.admin.name == "" || this.admin.name == undefined) {
    //         this.toastr.warningToastr("username or password cann't be blank.", '', {
    //             position: "bottom-center",
    //             toastTimeout: 2000,
    //             animate: "slideFromBottom"
    //         });
    //         return;
    //     }

    //     var body = {
    //         "name": this.admin.name,
    //         "email": this.admin.email,
    //         "id": this.admin.id
    //     }

    //     this._adminService.UpdateProfile(body).subscribe(
    //         resultArray => {
    //             if (resultArray.status == 200) {
    //                 this.toastr.successToastr(resultArray.message, 'Success!', {
    //                     position: "bottom-center",
    //                     toastTimeout: 2000,
    //                     animate: "slideFromBottom"
    //                 });
    //                 this.admin = resultArray.data[0];
    //                 window.localStorage.setItem('user', JSON.stringify(resultArray.data[0]));

    //             }
    //             else {
    //                 this.toastr.warningToastr(resultArray.message, '', {
    //                     position: "bottom-center",
    //                     toastTimeout: 2000,
    //                     animate: "slideFromBottom"
    //                 });
    //             }
    //         },
    //         error => {
    //             this.spinner.hide();
    //             this.toastr.warningToastr(error, '', {
    //                 position: "bottom-center",
    //                 toastTimeout: 2000,
    //                 animate: "slideFromBottom"
    //             });
    //             return;
    //         });
    // }

    changePassword(form: NgForm) {
        if (this.admin.confirmPassword != this.admin.newpassword) {
            this.toastr.warningToastr("New password and confirm password do not match.", '', {
                position: "bottom-center",
                toastTimeout: 2000,
                animate: "slideFromBottom"
            });
        }
        else {
            var data = new FormData();
            data.append("newpassword", this.admin.newpassword);
            data.append("oldpassword", this.admin.oldpassword),
                data.append("id", this.Id);
            this.spinner.show();
            this._adminService.ChangePassword(data).subscribe(
                resultArray => {
                    if (resultArray.status == 200) {
                        this.toastr.successToastr(resultArray.message, 'Success!', {
                            position: "bottom-center",
                            toastTimeout: 2000,
                            animate: "slideFromBottom"
                        });
                        this.admin = new Admin();
                        form.resetForm();
                        this.router.navigate(['']);

                    }
                    else {
                        this.toastr.warningToastr(resultArray.message, '', {
                            position: "bottom-center",
                            toastTimeout: 2000,
                            animate: "slideFromBottom"
                        });
                    }
                    this.spinner.hide();
                },
                error => {
                    this.toastr.warningToastr(error, '', {
                        position: "bottom-center",
                        toastTimeout: 2000,
                        animate: "slideFromBottom"
                    });
                });
        }
    }

    isNullOrEmpty(data) {
        return (data == undefined || data == null || data == "") ? "NA" : data;
    }
}