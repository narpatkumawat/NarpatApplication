import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ForgotpasswordRoutingModule } from './forgotpassword-routing-module';
import { ForgotPasswordComponent } from './forgot-password.component';
import { MenuModule } from '../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../services/admin.service';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        ForgotpasswordRoutingModule,
        MenuModule,NgxSpinnerModule
    ],
    declarations: [
        ForgotPasswordComponent
    ],
    exports: [],
    providers: [AdminService]
})
export class ForgotpasswordModule {
}
