import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { Admin } from '../../wrappers/admin';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  flag: any = 2;
  admin: Admin;
  constructor(public router: Router, private _adminService: AdminService, private spinner: NgxSpinnerService, private toastr: ToastrManager) {
    this.admin = new Admin();
  }

  ngOnInit() {
  }

  forgotPassword() {
    var data = new FormData();
    data.append("email", this.admin.email);
    data.append("flag", this.flag);

    this.spinner.show();
    this._adminService.forgotPassword(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.router.navigate(['/']);
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
}
