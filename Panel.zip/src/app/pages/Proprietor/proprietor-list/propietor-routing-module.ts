import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProprietorListComponent } from './proprietor-list.component';

const routes: Routes = [
    { path: '', component: ProprietorListComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class PropietorListRoutingModule {
}
