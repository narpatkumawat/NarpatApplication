import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { ProprietorService } from '../../../services/proprietor.service';
import { MasterService } from '../../../services/master.service';
import 'datatables.net';
import 'datatables.net-bs4';
declare var $: any;

@Component({
  selector: 'app-proprietor-list',
  templateUrl: './proprietor-list.component.html',
  styleUrls: ['./proprietor-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ProprietorListComponent implements OnInit {
  dataTable: any;
  properietorArr: any[];
  stateArr: any[];
  cityArr: any[];
  blockArr: any[];
  stateId: any;
  cityId: any;
  blockId: any;
  status: any;
  p: number = 1;

  constructor(public router: Router, private _properietorService: ProprietorService, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.allState();
    this. dataHide();
  }
  dataHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }
  proprietorSearch() {
    if (this.stateId == undefined && this.cityId == undefined && this.blockId == undefined && this.status == undefined) {
      this.toastr.warningToastr("Please select any value ", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }

    var data = {
      "stateId": this.stateId,
      "cityId": this.cityId == undefined ? 0 : this.cityId,
      "blockId": this.blockId == undefined ? 0 : this.blockId,
      "status": this.status == undefined ? 3 : this.status,
    }
    this.spinner.show();
    this._properietorService.proprietorSearch(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.properietorArr = resultArray.propsearchList;
          this.chRef.detectChanges();
          $('#example-table').DataTable({
            "paging": false,
            "bSort": false,
            "info": false,
            "bDestroy": true
          });
            this.dataShow();
        }
        else {
          this.properietorArr = [];
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allCity(stateId) {
    if (stateId == "undefined") {
      stateId = 0;
    }
    this.spinner.show();
    this._masterService.getAllCity(stateId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.cityList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  allblockbyId(cityId) {
    if (cityId == "undefined") {
      cityId = 0;
    }
    this.spinner.show();
    this._masterService.getAllBlock(cityId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.blockArr = resultArray.blockList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  isTrueOrFalse(data) {
    if (data == true) {
      return "Active"
    }
    else if (data == false) {
      return "Inactive"
    }
  }

  isNullOrEmpty(data) {
    return (data == undefined || data == null || data == "") ? "NA" : data;
  }
}
