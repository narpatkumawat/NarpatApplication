import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PropietorListRoutingModule } from './propietor-routing-module';
import { ProprietorListComponent } from '../../Proprietor/proprietor-list/proprietor-list.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProprietorService } from '../../../services/proprietor.service';
import { MasterService } from '../../../services/master.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        PropietorListRoutingModule,
        MenuModule,
        NgxSpinnerModule,
        NgxPaginationModule
    ],
    declarations: [
        ProprietorListComponent
    ],
    exports: [],
    providers: [ProprietorService, MasterService]
})


export class PropietorListModule {
}
