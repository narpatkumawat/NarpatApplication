import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AddProperitorRoutingModule } from './properitor-routing-module';
import { AddProperitoeComponent } from '../../Proprietor/add-properitoe/add-properitoe.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProprietorService } from '../../../services/proprietor.service';
import { MasterService } from '../../../services/master.service';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        AddProperitorRoutingModule,
        MenuModule,NgxSpinnerModule
    ],
    declarations: [
        AddProperitoeComponent
    ],
    exports: [

    ],
    providers: [ProprietorService,MasterService]
})


export class AddProperitorModule {
}
