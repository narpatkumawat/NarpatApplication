import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { Proprietor } from '../../../wrappers/proprietor';
import { ProprietorService } from '../../../services/proprietor.service'
import { MasterService } from '../../../services/master.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-properitoe',
  templateUrl: './add-properitoe.component.html',
  styleUrls: ['./add-properitoe.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AddProperitoeComponent implements OnInit {
  propObj: any;
  stateId: any;
  cityId: any;
  blockId: any;
  stateArr: any[];
  cityArr: any[];
  blockArr: any[];
  isActive: any;

  constructor(public router: Router, private _properietorService: ProprietorService, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.propObj = new Proprietor();
  }

  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.allState();
  }

  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allCity(stateId) {
    this.spinner.show();
    this._masterService.getAllCity(stateId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.cityList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  allblockbyId(cityId) {
    this.spinner.show();
    this._masterService.getAllBlock(cityId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.blockArr = resultArray.blockList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  addProp(form: NgForm) {
    if (this.propObj.password != this.propObj.confirmPassword) {
      this.toastr.warningToastr("Password and confirm password do not match.", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
    }
    else {
      this.spinner.show();
      var data = form.value;
      this._properietorService.addProprietor(data).subscribe(
        resultArray => {
          if (resultArray.status == 200) {
            this.toastr.successToastr(resultArray.message, 'Success!', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.propObj = new Proprietor();
            form.resetForm();
            this.router.navigate(['/proprietorlist']);
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.spinner.hide();
          }
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
}

