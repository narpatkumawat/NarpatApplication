import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { Router, ParamMap, Params, ActivatedRoute } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { Proprietor } from '../../../wrappers/proprietor';
import { ProprietorService } from '../../../services/proprietor.service'
import { MasterService } from '../../../services/master.service';
import { Subscription } from 'rxjs/Subscription'

@Component({
  selector: 'app-edit-proprietor',
  templateUrl: './edit-proprietor.component.html',
  styleUrls: ['./edit-proprietor.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditProprietorComponent implements OnInit {
  subScription: Subscription;
  id: string;
  stateArr: any[];
  cityArr: any[];
  blockArr: any[];
  cityId: any;
  stateId: any;
  blockId: any;
  prop: any;
  isActive: any;
  data: any;
  statusList: any;

  constructor(public router: Router, private _activatedRoute: ActivatedRoute, private _properietorService: ProprietorService, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.prop = new Proprietor();
  }
  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.fnIsActive();
    this.allState();
    this.subScription = this._activatedRoute.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id')
    });
    if (this.id != "") {
      this.spinner.show();
      this._properietorService.getproprietorById(this.id).subscribe(
        resultArray => {
          if (resultArray.status = 200) {
            this.prop = resultArray;
            this.stateId = this.prop.stateId;
            this.cityId = this.prop.cityId;
            this.blockId = this.prop.blockId;
            this.isActive = this.prop.IsActive;
            if (this.prop.IsActive == true) {
              this.prop.status = 1;
            }
            else {
              this.prop.status = 0;
            }
            this.allCity(this.stateId);
            this.allblockbyId(this.cityId)
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
  fnIsActive() {
    this.statusList = this.data = [
      {
        "Id": 1,
        "status": "Active"
      },
      {
        "Id": 0,
        "status": "Inactive"
      }
    ]
  }
  updateProp() {
    if (this.prop.propriterName == "" || this.prop.propriterName == undefined) {
      this.toastr.warningToastr("Please enter propriter name ", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return
    }
    else if (this.cityId == "" || this.cityId == 0) {
      this.toastr.warningToastr("Please select city name", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return
    }
    else if (this.blockId == "" || this.blockId == 0) {
      this.toastr.warningToastr("Please select block name", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return
    }
    else if (this.prop.address == "" || this.prop.address == 0) {
      this.toastr.warningToastr("Please enter address", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return
    }
    else {
      var data = {
        "propriterName": this.prop.propriterName,
        "framName": this.prop.framName,
        "stateId": this.stateId,
        "cityId": this.cityId,
        "blockId": this.blockId,
        "address": this.prop.address,
        "mobile": this.prop.mobile,
        "email": this.prop.email,
        "password": this.prop.password,
        "isActive": this.prop.status == 1 ? true : false,
        "id": this.prop.id
      }
      this.spinner.show();
      this._properietorService.editProprietor(data).subscribe(
        resultArray => {
          if (resultArray.status == 200) {
            this.toastr.successToastr(resultArray.message, 'Success!', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.router.navigate(['/proprietorlist']);
          }
          else {
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
            this.spinner.hide();
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allCity(stateId) {
    this.spinner.show();
    this._masterService.getAllCity(stateId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.cityList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allblockbyId(cityId) {
    this.spinner.show();
    this._masterService.getAllBlock(cityId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.blockArr = resultArray.blockList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
}
