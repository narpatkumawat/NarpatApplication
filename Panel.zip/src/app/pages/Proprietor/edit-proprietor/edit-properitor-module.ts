import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EditProperitorRoutingModule } from './edit-routing-module';
import { EditProprietorComponent } from '../../Proprietor/edit-proprietor/edit-proprietor.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProprietorService } from '../../../services/proprietor.service';
import { MasterService } from '../../../services/master.service';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        EditProperitorRoutingModule,
        MenuModule,NgxSpinnerModule
    ],
    declarations: [
        EditProprietorComponent
    ],
    exports: [

    ],
    providers: [ProprietorService,MasterService]
})


export class EditProperitorModule {
}
