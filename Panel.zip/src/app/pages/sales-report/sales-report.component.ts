import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { MasterService } from '../../services/master.service';
import { SaleReport } from '../../wrappers/sale-report';
import 'datatables.net';
import 'datatables.net-bs4';
declare var $: any;

@Component({
  selector: 'app-sales-report',
  templateUrl: './sales-report.component.html',
  styleUrls: ['./sales-report.component.css']
})
export class SalesReportComponent implements OnInit {
  dataTable: any;
  properietorArr: any[];
  stateArr: any[];
  cityArr: any[];
  blockArr: any[];
  stateId: any;
  cityId: any;
  blockId: any;
  properArr: any[];
  salereport: SaleReport;
  saleList: SaleReport[];
  p: number = 1;

  constructor(public router: Router, private _masterService: MasterService, private spinner: NgxSpinnerService,
    private toastr: ToastrManager, private chRef: ChangeDetectorRef) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }
    this.salereport = new SaleReport();
  }

  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.allState();
    this.dataHide();
  }

  dataHide() {
    var data = document.getElementById('DisPage')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('DisPage')
    data.style.display = 'block'
  }

  allState() {
    this.spinner.show();
    this._masterService.getAllState().subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.stateArr = resultArray.stateList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
  allCity(stateId) {
    if (stateId == "undefined") {
      stateId = 0;
    }
    this.spinner.show();
    this._masterService.getAllCity(stateId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.cityArr = resultArray.cityList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  allblockbyId(cityId) {
    if (cityId == "undefined") {
      cityId = 0;
    }
    this.spinner.show();
    this._masterService.getAllBlock(cityId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.blockArr = resultArray.blockList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  allProprietorbyBlock(blockId) {
    if (blockId == "undefined") {
      blockId = 0;
    }
    this.spinner.show();
    this._masterService.getProprietorByBlock(blockId).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.properArr = resultArray.propList;
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  searchSaleReport() {
    if (this.salereport.fromdate == undefined && this.salereport.todate == undefined) {
      this.toastr.warningToastr("Please select from date and to date", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else if (this.salereport.fromdate == undefined) {
      this.toastr.warningToastr("Please select from date", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }

    else if (this.salereport.todate == undefined) {
      this.toastr.warningToastr("Please select to date", '', {
        position: "bottom-center",
        toastTimeout: 2000,
        animate: "slideFromBottom"
      });
      return;
    }
    else {
      var data = {
        "fromdate": this.salereport.fromdate,
        "todate": this.salereport.todate,
        "PropriterId": this.salereport.PropriterId == undefined ? 0 : this.salereport.PropriterId,
        "stateid": this.stateId == undefined ? 0 : this.stateId,
        "cityid": this.cityId == undefined ? 0 : this.cityId,
        "blockid": this.blockId == undefined ? 0 : this.blockId
      }
      this.spinner.show();
      this._masterService.searchsaleReport(data).subscribe(
        resultArray => {
          debugger
          if (resultArray.status == 200) {
            this.saleList = resultArray.salesreportList;
            this.chRef.detectChanges();
            $('#example-table').DataTable({
              "paging": false,
              "bSort": false,
              "info": false,
              "bDestroy": true
            });
            this.dataShow();
          }
          else {
            this.saleList = [];
            this.toastr.warningToastr(resultArray.message, '', {
              position: "bottom-center",
              toastTimeout: 2000,
              animate: "slideFromBottom"
            });
          }
          this.spinner.hide();
        },
        error => {
          this.toastr.warningToastr(error, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        });
    }
  }
}
