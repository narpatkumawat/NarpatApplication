import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SalesReportRoutingModule } from './sales-report-routing-module';
import { SalesReportComponent } from './sales-report.component';
import { MenuModule } from '../../components/menu/menu.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { MasterService } from '../../services/master.service';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        SalesReportRoutingModule,
        MenuModule,
        NgxSpinnerModule,
        NgxPaginationModule,
        BsDatepickerModule.forRoot()
    ],
    declarations: [
        SalesReportComponent
    ],
    exports: [],
    providers: [ MasterService]
})

export class SalesReportModule {
}
