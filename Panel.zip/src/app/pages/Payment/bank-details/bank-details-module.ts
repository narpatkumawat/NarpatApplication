import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BankDetailsRoutingModule } from '../bank-details/bank-details-routing-module';
import { BankDetailsComponent } from '../bank-details/bank-details.component';
import { MenuModule } from '../../../components/menu/menu.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AdminService } from '../../../services/admin.service';
import {LedgerService} from '../../../services/ledger.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    imports: [
        CommonModule,FormsModule,
        BankDetailsRoutingModule,
        MenuModule,
        NgxSpinnerModule,
        BsDatepickerModule.forRoot(),
        NgxPaginationModule
    ],
    declarations: [
        BankDetailsComponent
    ],
    exports: [],
    providers: [AdminService,LedgerService]
})

export class BankDetailsModule {
}
