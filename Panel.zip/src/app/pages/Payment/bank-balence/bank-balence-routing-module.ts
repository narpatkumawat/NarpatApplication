import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BankBalenceComponent } from '../bank-balence/bank-balence.component';

const routes: Routes = [
    { path: '', component: BankBalenceComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class BankBalenceRoutingModule {
}
