import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LedgerService } from '../../../services/ledger.service';
import { DepositAmount } from '../../../wrappers/deposit-amount';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-bank-balence',
  templateUrl: './bank-balence.component.html',
  styleUrls: ['./bank-balence.component.css']
})
export class BankBalenceComponent implements OnInit {
  depositArr: any[];
  deposit: DepositAmount;
  constructor(public router: Router, private _ledgerService: LedgerService, private spinner: NgxSpinnerService, private toastr: ToastrManager, ) {
    var user = JSON.parse(window.localStorage.getItem('user')) as any;
    if (user == undefined || user == null) {
      this.router.navigate(['']);
    }

    this.deposit = new DepositAmount();
  }

  _onKeypress(event) {
    event.preventDefault();
  }
  _onlynumber(event) {
    if (event.keyCode == 46 || (event.keyCode >= 48 && event.keyCode <= 57)) {
      return true;
    }
    else {
      event.preventDefault();
    }
  }

  ngOnInit() {
    this.dataHide();
  }

  dataHide() {
    var data = document.getElementById('bank')
    data.style.display = 'none'
  }

  dataShow() {
    var data = document.getElementById('bank')
    data.style.display = 'block'
  }

  varifyData() {
    var data = {
      "TranslationId": this.deposit.TransactionId,
      "denaminalionamt": this.deposit.CreaditAmt
    }
    this.spinner.show();
    this._ledgerService.memberVerify(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.depositArr = resultArray.propsearchList;
          sessionStorage.setItem("Mid", this.depositArr[0].id);
          this.dataShow();
        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }

  depositbankBalance() {
    var data = {
      "TransactionId": this.deposit.TransactionId,
      "CreaditAmt": this.deposit.CreaditAmt,
      "FromDate": this.deposit.FromDate,
      "ToDate": this.deposit.ToDate,
      "mId": sessionStorage.getItem("Mid")
    }
    this.spinner.show();
    this._ledgerService.depositBalance(data).subscribe(
      resultArray => {
        if (resultArray.status == 200) {
          this.toastr.successToastr(resultArray.message, 'Success!', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
          this.deposit.TransactionId = '';
          this.deposit.CreaditAmt = null;
          this.deposit.FromDate = null;
          this.deposit.ToDate = null
          this.dataHide();

        }
        else {
          this.toastr.warningToastr(resultArray.message, '', {
            position: "bottom-center",
            toastTimeout: 2000,
            animate: "slideFromBottom"
          });
        }
        this.spinner.hide();
      },
      error => {
        this.toastr.warningToastr(error, '', {
          position: "bottom-center",
          toastTimeout: 2000,
          animate: "slideFromBottom"
        });
      });
  }
}