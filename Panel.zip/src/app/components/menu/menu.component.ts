import { Component, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import 'metismenu';
import { Admin } from '../../wrappers/admin';
declare var $: any;


@Component({
    selector: 'menu-page',
    templateUrl: './menu.component.html',
    styleUrls: ['./menu.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class MenuComponent implements AfterViewInit {
    adminName: string;
    roleType: any;

    ngAfterViewInit(): void {
        $("#sidebarnav").metisMenu();
        this.role();
    }

    constructor(public router: Router) {
        var user = JSON.parse(window.localStorage.getItem('user')) as Admin;
        if (user == undefined || user == null) {
            this.router.navigate(['']);
        }
        else {
            this.adminName = user.name;
            this.roleType = user.roleType
        }
    }
    role() {
        if (this.roleType == "User") {
            var data = document.getElementById('user');
            data.style.display = "none";
        }
        else {
            var data = document.getElementById('user');
            data.style.display = "block";
        }
    }
    logout() {
        this.router.navigate(['']);
    }

    toggleMenuClick() {
        $("body").hasClass("mini-sidebar") ? ($("body").trigger("resize"), $(".scroll-sidebar, .slimScrollDiv").css("overflow", "hidden").parent().css("overflow", "visible"),
            $("body").removeClass("mini-sidebar"), $(".navbar-brand span").show(), $(".navbar-brand img").css("width", "20%")) : ($("body").trigger("resize"),
                $(".scroll-sidebar, .slimScrollDiv").css("overflow-x", "visible").parent().css("overflow", "visible"),
                $("body").addClass("mini-sidebar"), $(".navbar-brand span").hide(), $(".navbar-brand img").css("width", "70%"));
    }
}